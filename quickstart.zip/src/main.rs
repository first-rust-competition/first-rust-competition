// This file is part of [YOUR PROJECT], which is free software: you
// can redistribute it and/or modify it under the terms of the GNU General
// Public License version 3 as published by the Free Software Foundation. See
// <https://www.gnu.org/licenses/> for a copy.

extern crate wpilib;
use wpilib::*;

fn main() {
    let robot = RobotBase::new().expect("HAL FAILED");

    // Do some setup

    RobotBase::start_competition();

    // In-match code
}
